/* GitHub sign-in through Supabase for Goyame.
   This file contains only the public Supabase URL and publishable key.
   GitHub OAuth Client Secret must remain in Supabase Dashboard. */
(function () {
    "use strict";

    var SUPABASE_URL = "https://vgqeystxgtllkyqcnper.supabase.co";
    var SUPABASE_KEY = "sb_publishable_VBSHCNzOk9eBW1sSlNgHTA_1maHSou3";
    var ALLOWED_GITHUB_USER = "xifarabi";
    var ALLOWED_GITHUB_ID = "349310937";

    var clientPromise = null;

    function loadClient() {
        if (window.supabase && window.supabase.createClient) {
            if (!window.__goamiSupabaseClient) {
                window.__goamiSupabaseClient =
                    window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
            }
            return Promise.resolve(window.__goamiSupabaseClient);
        }

        if (clientPromise) return clientPromise;

        clientPromise = new Promise(function (resolve, reject) {
            var script = document.createElement("script");
            script.src = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js";
            script.onload = function () {
                try {
                    window.__goamiSupabaseClient =
                        window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
                    resolve(window.__goamiSupabaseClient);
                } catch (error) {
                    reject(error);
                }
            };
            script.onerror = function () {
                reject(new Error("Could not load Supabase sign-in. Check your internet connection."));
            };
            document.head.appendChild(script);
        });

        return clientPromise;
    }

    function isAllowed(user) {
        if (!user) return false;

        var records = [];

        function addRecord(source, fallbackId) {
            if (!source) return;
            var username = source.user_name ||
                source.preferred_username ||
                source.login ||
                source.nickname ||
                "";
            var providerId = source.provider_id ||
                source.sub ||
                source.id ||
                fallbackId ||
                "";
            if (username || providerId) {
                records.push({
                    username: String(username).toLowerCase(),
                    providerId: String(providerId)
                });
            }
        }

        var metadata = user.user_metadata || {};
        addRecord(metadata, "");

        (Array.isArray(user.identities) ? user.identities : []).forEach(function (identity) {
            if (!identity || String(identity.provider || "").toLowerCase() !== "github") return;
            addRecord(identity.identity_data || {}, identity.id || "");
        });

        return records.some(function (record) {
            return record.username === ALLOWED_GITHUB_USER &&
                record.providerId === ALLOWED_GITHUB_ID;
        });
    }

    function notify(title, message, kind) {
        try {
            if (typeof showToast === "function") {
                showToast(title, message, kind);
            } else {
                alert(title + "\n\n" + message);
            }
        } catch (error) {
            alert(title + "\n\n" + message);
        }
    }

    async function getVerifiedSession() {
        var supabase = await loadClient();
        var result = await supabase.auth.getSession();
        if (result.error) throw result.error;

        var session = result.data && result.data.session;
        if (!session) return null;

        if (!isAllowed(session.user)) {
            await supabase.auth.signOut();
            notify("Access Denied", "This GitHub account is not authorized to sign in.", "err");
            return null;
        }

        return session;
    }

    window.loginGithub = async function () {
        try {
            var session = await getVerifiedSession();

            if (session) {
                notify("GitHub Verified", "Now enter your admin password to unlock your vault.", "ok");
                if (typeof authOpenAdmin === "function") {
                    authOpenAdmin();
                }
                return;
            }

            var supabase = await loadClient();
            var redirectUrl = window.location.origin + window.location.pathname;
            var result = await supabase.auth.signInWithOAuth({
                provider: "github",
                options: {
                    redirectTo: redirectUrl,
                    scopes: "read:user"
                }
            });

            if (result.error) throw result.error;
        } catch (error) {
            notify("GitHub Login Error",
                error && error.message ? error.message : "Please try again.", "err");
        }
    };

    // Supabase exchanges the OAuth callback for a session automatically.
    // Verify the returning account before allowing the user to continue.
    if (/[?#&](code|access_token|error)=/.test(window.location.search + window.location.hash)) {
        getVerifiedSession().then(function (session) {
            if (session) {
                notify("GitHub Verified", "Tap Continue with GitHub again, then enter your admin password.", "ok");
            }
            if (window.history && window.history.replaceState) {
                window.history.replaceState(null, "", window.location.pathname);
            }
        }).catch(function (error) {
            notify("GitHub Login Error",
                error && error.message ? error.message : "Could not verify the GitHub account.", "err");
        });
    }
})();
